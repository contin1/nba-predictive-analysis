# 🏀 NBA Analytics Portfolio — 2025-26 Season

> Built on `nba_api 1.11.4` — real NBA Stats API data, no scraping.

## Stack
| Layer | Tech |
|-------|------|
| Frontend | Streamlit 1.35+ |
| Data | nba_api 1.11.4 (168 endpoints) |
| Viz | Plotly + Matplotlib |
| Hosting | Run locally or deploy to Streamlit Cloud / Heroku |

## Modules

| # | Module | Key Endpoints |
|---|--------|--------------|
| 1 | **Player Profile** | `PlayerCareerStats`, `PlayerEstimatedMetrics`, `LeagueDashPlayerStats(Advanced)`, `PlayerDashboardByClutch` |
| 2 | **Shot Chart Lab** | `ShotChartDetail` (LOC_X/LOC_Y hex bins), `PlayerDashPtShots` (dribble, touch time, defender distance) |
| 3 | **Hustle & Tracking** | `LeagueHustleStatsPlayer` (deflections, contested shots, charges), `LeagueDashPtStats(SpeedDistance)` |
| 4 | **League Leaderboard** | `LeagueDashPlayerStats` (Base/Advanced/Misc/Scoring), `LeagueDashPlayerClutch` |
| 5 | **Play-Type Breakdown** | `SynergyPlayTypes` (PPP + percentile for 11 offensive play types) |

## Key Advanced Stats Explained

| Stat | Source | Meaning |
|------|--------|---------|
| `TS%` | LeagueDashPlayerStats(Advanced) | True shooting % — FG+3PT+FT combined efficiency |
| `eFG%` | LeagueDashPlayerStats(Advanced) | Effective FG% — 3PT weighted at 1.5× |
| `USG%` | LeagueDashPlayerStats(Advanced) | % of team plays used by player |
| `NET_RATING` | LeagueDashPlayerStats(Advanced) | Off rating − def rating per 100 poss |
| `PIE` | LeagueDashPlayerStats(Advanced) | Player Impact Estimate — NBA's composite metric |
| `E_NET_RATING` | PlayerEstimatedMetrics | RAPM-style estimated net rating |
| `PPP` | SynergyPlayTypes | Points per possession by play type |
| `PERCENTILE` | SynergyPlayTypes | League percentile rank for that play type |
| `DEFLECTIONS` | LeagueHustleStatsPlayer | Passes deflected (disruption metric) |
| `SCREEN_ASSISTS` | LeagueHustleStatsPlayer | Off-ball screens that directly created a made shot |
| `CHARGES_DRAWN` | LeagueHustleStatsPlayer | Offensive fouls drawn (IQ + effort metric) |

## How to Run

```bash
# Install dependencies
pip install -r requirements.txt

# Install nba_api from the included tarball (or pip install nba_api)
pip install nba_api-1.11.4.tar.gz

# Launch
streamlit run Home.py
```

Then open http://localhost:8501

## Notes
- Data is cached for 1 hour per session to respect NBA API rate limits
- Each API call includes a 0.7s delay to avoid 429 errors
- The NBA Stats API blocks some endpoints without proper headers — all requests include the required `x-nba-stats-token` headers
- `SynergyPlayTypes` may be restricted during off-season
- All data reflects the **2025-26 NBA Regular Season** by default

## Portfolio Credit
Built by **Nicholas Conti** as part of a basketball analytics engineering portfolio.
Repo: `nba-predictive-analysis`
